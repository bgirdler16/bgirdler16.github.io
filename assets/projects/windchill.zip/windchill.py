# Blake Girdler CSCI151 Section 00
# 08/31/2021
# Create a program that takes the temperature and wind speed to print the wind chill.

import sys
import stdio

# Assign inputs to variables and create a variable for the final wind chill.
windChill = float()
temperature = sys.argv[1]
speed = sys.argv[2]

# Print the temperature and wind speed back to user
stdio.writeln('Temperature = ' + temperature)
stdio.writeln('Wind speed = ' + speed)

# Prep variables for use in wind chill formula
temperature = abs(float(temperature))
speed = float(speed)

# Calculate the wind chill using National Weather Service formula
windChill = 35.74 + 0.6215 * temperature + (0.4275 * temperature - 35.75) * speed**0.16

# Change wind chill to a string for printing.
windChill = str(windChill)

# Print wind chill.
stdio.writeln('Wind Chill = ' + windChill)



