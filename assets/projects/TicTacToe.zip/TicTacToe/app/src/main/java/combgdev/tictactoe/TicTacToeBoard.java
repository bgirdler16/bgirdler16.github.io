package combgdev.tictactoe;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;

public class TicTacToeBoard extends View {

    private final int boardColor;
    private final int oColor;
    private final int xColor;
    private final int winLineColor;

    private boolean winningLine = false;


    private final Paint paint = new Paint();

    private final GameLogic game;

    private int cellSize = getWidth()/3;

    public TicTacToeBoard(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);

        game = new GameLogic();

        TypedArray a = context.getTheme().obtainStyledAttributes(attrs, R.styleable.TicTacToeBoard,
                0, 0);

        try{
            boardColor = a.getInteger(R.styleable.TicTacToeBoard_boardColor, 0);
            xColor = a.getInteger(R.styleable.TicTacToeBoard_xColor, 0);
            oColor = a.getInteger(R.styleable.TicTacToeBoard_oColor, 0);
            winLineColor = a.getInteger(R.styleable.TicTacToeBoard_winLineColor, 0);
        }finally{
            a.recycle();
        }


    }

    @Override
    protected void  onMeasure(int width, int height) {
        super.onMeasure(width, height);

        int dimension = Math.min(getMeasuredWidth(), getMeasuredHeight());

        cellSize = dimension/3;

        setMeasuredDimension(dimension, dimension);
    }
    @Override
    protected void onDraw(Canvas canvas) {
        paint.setStyle(Paint.Style.STROKE);
        paint.setAntiAlias(true);

        drawGameBoard(canvas);
        drawMarkers(canvas);

        if (winningLine) {
            paint.setColor(winLineColor);
            drawWinningLine(canvas);
        }

    }
    @SuppressLint("ClickableViewAccessibility")
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        float x = event.getX();
        float y = event.getY();

        int action = event.getAction();
        if (action == MotionEvent.ACTION_DOWN){
            int row = (int)Math.ceil(y/cellSize);
            int column = (int)Math.ceil(x/cellSize);

            if(!winningLine) {

                if (game.updateGameBoard(row, column)) {
                    invalidate();

                    if (game.winnerCheck()){
                        winningLine = true;
                        invalidate();
                    }

                    //this updates the player turn, and switches it.
                    if (game.getPlayer() % 2 == 0) {
                        game.setPlayer(game.getPlayer() - 1);
                    } else {
                        game.setPlayer(game.getPlayer() + 1);
                    }
                }
            }

            invalidate();
            return true;
        }
        return false;
    }

    private void drawGameBoard(Canvas canvas) {
        paint.setColor(boardColor);
        paint.setStrokeWidth(16);

        for (int c = 1; c < 3; c++) {
            canvas.drawLine(cellSize * c, 0, cellSize * c, canvas.getHeight(), paint);
        }
        for (int r = 1; r < 3; r++) {
            canvas.drawLine(0, cellSize * r, canvas.getHeight(), cellSize * r, paint);

        }
    }



    private void drawX(Canvas canvas, int row, int column){
        paint.setColor(xColor);

        canvas.drawLine((float) ((column+1)*cellSize - cellSize * 0.2),
                        (float)(row*cellSize + cellSize * 0.2),
                        (float) (column*cellSize + cellSize * 0.2),
                        (float)((row+1)*cellSize - cellSize * 0.2),
                        paint);

        canvas.drawLine((float)(column*cellSize + cellSize * 0.2),
                        (float)(row*cellSize + cellSize * 0.2),
                        (float)((column+1)*cellSize - cellSize * 0.2),
                        (float)((row+1)*cellSize - cellSize * 0.2),
                        paint);
    }

    private void drawO(Canvas canvas, int row, int column){
        paint.setColor(oColor);

        canvas.drawOval((float)(column*cellSize + cellSize * 0.2),
                        (float)(row*cellSize + cellSize * 0.2),
                        (float)((column*cellSize + cellSize) - cellSize * 0.2),
                        (float)((row*cellSize + cellSize ) - cellSize * 0.2),
                        paint);
    }
    private void drawMarkers(Canvas canvas) {
        for (int r = 0; r < 3; r++) {
            for (int c = 0; c < 3; c++) {
                if (game.getGameBoard()[r][c] != 0) {
                    if (game.getGameBoard()[r][c] == 1) {
                        drawX(canvas, r, c);
                    } else {
                        drawO(canvas, r, c);
                    }
                }
            }
        }
    }

    public void drawHorizontal(Canvas canvas, int row, int column) {
        canvas.drawLine(column,
                        row*cellSize + (float)cellSize/2,
                        cellSize*3,
                        row*cellSize + (float)cellSize/2,
                        paint);
    }
    public void drawVertical(Canvas canvas, int row, int column) {
        canvas.drawLine(column*cellSize  + (float)cellSize/2,
                              row,
                        column*cellSize + (float)cellSize/2,
                        cellSize*3,
                              paint);
    }
    public void drawDiagonalPos(Canvas canvas) {
        canvas.drawLine(0,
                        cellSize*3,
                        cellSize*3,
                        0,
                              paint);
    }
    public void drawDiagonalNeg(Canvas canvas) {
        canvas.drawLine(0,
                0,
                cellSize*3,
                cellSize*3,
                paint);
    }

    private void drawWinningLine(Canvas canvas) {
        int row = game.getWinType()[0];
        int column = game.getWinType()[1];

        switch (game.getWinType()[2]) {
            case 1:
                drawHorizontal(canvas, row, column);
                break;
            case 2:
                drawVertical(canvas, row, column);
                break;
            case 3:
                drawDiagonalNeg(canvas);
                break;
            case 4:
                drawDiagonalPos(canvas);
                break;
        }
    }
    public void setUpGame(Button playAgain, Button home, TextView playerDisplay, String[] names) {
        game.setPlayAgainBTN(playAgain);
        game.setHomeBTN(home);
        game.setPlayerTurn(playerDisplay);
        game.setPlayerNames(names);
    }

    public void resetGame() {
        game.resetGame();
        winningLine = false;
    }
}